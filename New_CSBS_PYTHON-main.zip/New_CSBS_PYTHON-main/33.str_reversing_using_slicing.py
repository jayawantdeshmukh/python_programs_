str = input("Enter a string: ")
reversed_string= str[::-1]
print("Reversed string:", reversed_string)