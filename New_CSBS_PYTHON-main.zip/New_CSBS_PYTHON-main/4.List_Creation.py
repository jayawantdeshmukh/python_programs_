# List is a type of Data Sructure.
# List should be stored in '[]' sqaure brackets.
# We can store multiple data-types in list.
# Lists are mutable means it can be modified after creation.
# Ex :
a = [1,2,3,4,5] # We created a list named 'a' and '1','2'.'3','4','5' are elements of list.
fruits = ['Apple','Banana','Kiwi'] #same as above example but we stored strings as example. 

print("a =",a)
print("Fruits =",fruits)