a = int(input("Enter a number :"))
if(a%2==0):
    print("a is even number.")# Means remainder eqal to zero means perfectly devided by 2.
else:
    print("a is not even.")