# Performing Basic Arithmatic operations..
# Definig two variables
a = 4
b = 3
# For Addition we use '+' sign:
print("Addition :",a+b)
# For Subtraction we use '-' sign:
print("Subtraction :",a-b)
# For Multiplication we use "*" sign:
print("Multiplication :",a*b)
# For Division we use "/" sign:
print("Division :",a/b)
# To get remainder of the division we use "%" (Modulus) sign.
print("Remainder :",a%b) # Output will be 1.