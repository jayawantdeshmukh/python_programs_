num1 = 10
num2 = 8
def mul_num(num1, num2):
    a = num1*num2
    return(a)
a = mul_num(num1, num2)
print(a)