length = 6
breadth = 8
def peri_rect(length, breadth):
    a = 2*(length+breadth)
    return(a)
a = peri_rect(length, breadth)
print(f"The Perimeter of Rectangle with sides {length} and {breadth} is {a}")