fruits = ['Apple','Banana','Kiwi','Grapes','Dragon-fruit','Mango'] # Created a list called fruits
print("Slice[1:4] =",fruits[1:4]) # We accessed elements 2nd ,3rd,4th .