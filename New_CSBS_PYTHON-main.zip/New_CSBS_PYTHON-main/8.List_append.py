# We can also add new element in list using "List_name.append('Element')"
Greetings = ['Good-Morning','Good-Afternoon']
print("Greetings :",Greetings)
# Adding new element - "Good-Night":
Greetings.append('Good-Night')
print("After Adding new element : ",Greetings)
# We can also add new element at a specific position using .insert(position,element)
Greetings.insert(1,'Hello')
print('New Greetings :',Greetings)