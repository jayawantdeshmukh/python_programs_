# We can compare numbers using comparison operators.
# Comparison Operators : '<','>','<=','>=','==','!='.
# Comparing Numbers using those operators and if-else.
# if-else is a control statement .
# Control Statement : Which cntrols the flow of statements.
a = 25
b = 6
if(b>a):
    print("a is greater than a.")
else:
    print("a is greater than b")
# this will print: a is greater than b