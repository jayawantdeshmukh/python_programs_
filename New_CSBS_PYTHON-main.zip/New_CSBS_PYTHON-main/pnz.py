def num(n):
    if n > 1:
        print("number is positive")

    elif n < 0:
        print("number is negative")

    else:
        print("number is zero")
n = int(input("Enter Your Number: "))
num(n)