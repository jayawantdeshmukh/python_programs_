a = input("Enter Anything : ")
print(len(a))