num1 = 16
num2 = 2
def div_num(num1, num2):
    a = num1/num2
    return(a)
a = div_num(num1, num2)
print(a)