str = input("Enter Any string : ")
i=0
for ch in str:
    print(str[i])
    i+=1
print(f"all the spaces have been replaced by - in the given sentence and it looks like this : {str}")