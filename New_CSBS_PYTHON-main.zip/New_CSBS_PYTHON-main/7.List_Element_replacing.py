# Since list are mutable we can replace one element with other .
days = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday']
# Before Modification:
print("Days :",days) 
days[6] = 'Holiday'
# After Modifying ..
print("After Modifying :",days)