# creating a tuple using round brackets
cars = ("BMW","Dodge-Challenger","Bugatti-chiron","Nissan-GTR")
# Accessing Elements :
print("Tuple :",cars)
print("My favourite Car :",cars[2])