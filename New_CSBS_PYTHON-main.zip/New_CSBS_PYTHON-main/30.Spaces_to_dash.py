a = input("Enter Any sentence : ")
length = len(a)
spaces = 0
a = a.replace(" ", "-")
print(f"After replacing spaces by - : {a}")