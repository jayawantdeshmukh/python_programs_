a = 3
if(a%2!=0):
    print("a is odd number.")# Means remainder not eqal to zero means not perfectly devided by 2.
else:
    print("a is not odd number.")