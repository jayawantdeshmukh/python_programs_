# Creating a list named 'a'.
a = [1,2,3,4,5] # We created a list named 'a' and '1','2'.'3','4','5' are elements of list.
print("First Element :",a[0]) # Accessing the First element.
print("Second Element :",a[1]) # Accesssing the second element.
print("Third Element :",a[2]) # Accesssing the third element.
print("Fourth Element :",a[3]) # Accesssing the fourth element.
print("Fifth Element :",a[4]) # Accesssing the fifth element.