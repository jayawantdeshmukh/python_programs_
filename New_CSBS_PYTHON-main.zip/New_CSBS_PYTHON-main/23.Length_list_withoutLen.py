list = [1,2,3,4,5,6]
len = 0
for item in list:
    len+=1
print ("list Length is : ",len)