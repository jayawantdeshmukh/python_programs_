num1 = 7
num2 = 3
def sub_num(num1, num2):
    a = num1-num2
    return(a)
a = sub_num(num1, num2)
print(a)