num1 = 6
num2 = 8
def add_num(num1, num2):
    a = num1+num2
    return(a)
a = add_num(num1, num2)
print(a)