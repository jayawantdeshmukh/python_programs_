# Tuple is also a Type of Data Structure :
# It is stored in round brackets 
# Tuple creation:
# Tuples are immutable means we only can slice it or access elements ..!
a = {10,20,30,40,50,60,}
print("Tuple :",a)
