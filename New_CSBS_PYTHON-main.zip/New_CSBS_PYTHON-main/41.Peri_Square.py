side = 8
def peri_square(side):
    a = side*4
    return(a)
a = peri_square(side)
print(f"The Perimeter of Square with side {side} is {a}")