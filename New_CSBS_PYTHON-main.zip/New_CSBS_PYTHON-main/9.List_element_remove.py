# We also can Remove elements from list.
Alphabets = ['A','B','C','D','E']
print('List :',Alphabets)
# Remove c from the list :
Alphabets.remove('C')
print('After Modifying :',Alphabets)