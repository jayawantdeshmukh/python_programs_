# creating a tuple using round brackets
cars = ("BMW","Dodge-Challenger","Bugatti-chiron","Nissan-GTR")
# Slicing tuple:
print("Random Slicing :",cars[1:3])